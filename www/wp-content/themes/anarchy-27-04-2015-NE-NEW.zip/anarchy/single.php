<?php
/**
 * The template for displaying all single posts.
 *
 * @package direct_action
 */

get_header(); ?>

	<div id="primary" class="content-area container col-sm-9">
		<main id="main" class="site-main row" role="main">

		<?php while ( have_posts() ) : the_post(); ?>

			<?php get_template_part( 'content', 'single' ); ?>

			<?php the_post_navigation(); ?>
			

		<?php endwhile; // end of the loop. ?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
