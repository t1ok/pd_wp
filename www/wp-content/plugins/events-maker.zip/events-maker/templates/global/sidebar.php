<?php
/**
 * The template for displaying sidebar
 * 
 * Override this template by copying it to yourtheme/global/sidebar.php
 *
 * @author 	Digital Factory
 * @package Events Maker/Templates
 * @since 	1.2.0
 */

if ( ! defined( 'ABSPATH' ) )
	exit; // exit if accessed directly

get_sidebar( 'events' );